from django.apps import AppConfig


class HoneyConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'honey'
    verbose_name = 'Продуктілер тізімі '
